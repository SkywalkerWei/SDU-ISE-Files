x=zeros(1,11);% 创建一个1行11列的零向量x
x(6)=1;% 在第6个位置（即x(6)）设置为1，表示单位脉冲信号（δ(n)）  
n=-5:5;% 创建一个从-5到5的向量n 
figure(1);%创建一个新图形窗口，图形编号为1 
stem(n,x,'.');xlabel('n');ylabel('x(n)');title('δ(n)');% 设置x轴标签为'n' ,% 设置y轴标签为'x(n)',% 设置图形标题为'δ(n)' 
box off;% 关闭图形框，以使图形更简洁 
x2=ones(11);% 创建一个11x11的矩阵x2，所有元素初始化为
n=-5:5;% 创建一个从-5到5的向量n 
figure(2);%创建一个新图形窗口，图形编号为2
stem(n,x2,'.');xlabel('n');ylabel('x(n)');title('u(n)');% 设置x轴标签为'n' ,% 设置y轴标签为'x(n)',% 设置图形标题为'u(n)' 
box off;% 关闭图形框，以使图形更简洁 
n=-10:10;%创建一个从-10到10的向量n 
x3=2*sin(pi*n/9+pi/3);%计算一个序列x3，表达式为2*sin(pi*n/9 + pi/3) 
figure(3);%创建一个新图形窗口，图形编号为3
stem(n,x3,'.');xlabel('n');ylabel('x(n)');title('2*sin(pi*n/9+pi/3)');%设置x轴标签为'n' ,% 设置y轴标签为'x(n)',% 设置图形标题为'2*sin(pi*n/9+pi/3)' 
box off;% 关闭图形框，以使图形更简洁 
n=0:0.1:10;%创建一个从0到10，步长为0.1的向量n 
a=2;% 定义常数a，设置为2
x4=2*exp(1j*2*n);% 计算一个复数序列x4，表达式为2*exp(1j*2*n)
figure(4);%创建一个新图形窗口，图形编号为4
stem(n,x4,'.');xlabel('n');ylabel('x(n)');title('2*exp(1j*2*n)');%设置x轴标签为'n' ,% 设置y轴标签为'x(n)',% 设置图形标题为2*exp(1j*2*n) 
box off;% 关闭图形框，以使图形更简洁 
n=1:10;%创建一个从1到10的向量n 
x5=1.5.^n;%计算x5，表示1.5的n次方，结果为一个包含从1.5^1到1.5^10的序列
figure(5);%创建一个新图形窗口，图形编号为5
stem(n,x5,'.');xlabel('n');ylabel('x(n)');title('x=1.5.^n');%设置x轴标签为'n' ,% 设置y轴标签为'x(n)',% 设置图形标题为x=1.5.^n 
box off;% 关闭图形框，以使图形更简洁 
% 定义时间向量t  
t = 0:0.001:2; % 生成从0到2秒，步长为0.001秒的时间向量  

% 定义频率 Omegas  
Omega1 = 2 * pi;  % 频率1  
Omega2 = 3 * pi;  % 频率2  
Omega3 = 6 * pi;  % 频率3  
Omega4 = 8 * pi;  % 频率4  

% 定义连续时间信号 x_a(t)  
x_a_t = 5 * cos(Omega1 * t) - 3 * cos(Omega2 * t) + 2 * cos(Omega3 * t) + cos(Omega4 * t);   

% 绘制 x_a(t) 的波形  
figure(1);   
plot(t, x_a_t); % 使用plot函数绘制波形  
xlabel('Time (s)'); % x轴标签  
ylabel('x_a(t)'); % y轴标签  
title('Continuous Time Signal x_a(t)'); % 图标题  
grid on; % 显示网格  

% 设置抽样时间间隔  
Ts1 = 1/12; % 12 Hz抽样频率  
Ts2 = 1/20; % 20 Hz抽样频率  

% 创建时间向量，以抽样间隔生成抽样序列  
t_sample1 = 0:Ts1:2; % 12Hz抽样时间点  
t_sample2 = 0:Ts2:2; % 20Hz抽样时间点  

% 生成抽样信号  
x_sample1 = 5 * cos(Omega1 * t_sample1) - 3 * cos(Omega2 * t_sample1) + 2 * cos(Omega3 * t_sample1) + cos(Omega4 * t_sample1);  
x_sample2 = 5 * cos(Omega1 * t_sample2) - 3 * cos(Omega2 * t_sample2) + 2 * cos(Omega3 * t_sample2) + cos(Omega4 * t_sample2);  

% 绘制抽样序列  
figure(2);  
subplot(2, 1, 1); % 12Hz抽样  
stem(t_sample1, x_sample1, 'r', 'filled'); % 用stem画出抽样点  
xlabel('Time (s)'); % x轴标签  
ylabel('Sampled x_a(t) at 12 Hz'); % y轴标签  
title('Sampled Signal x_a(t) at 12 Hz'); % 图标题  
grid on; % 显示网格  

subplot(2, 1, 2); % 20Hz抽样  
stem(t_sample2, x_sample2, 'b', 'filled'); % 用stem画出抽样点  
xlabel('Time (s)'); % x轴标签  
ylabel('Sampled x_a(t) at 20 Hz'); % y轴标签  
title('Sampled Signal x_a(t) at 20 Hz'); % 图标题  
grid on; % 显示网格
