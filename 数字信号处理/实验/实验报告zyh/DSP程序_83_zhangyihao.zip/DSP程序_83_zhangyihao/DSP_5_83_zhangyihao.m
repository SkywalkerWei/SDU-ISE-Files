% main.m

n = input('输入阶数：');
coefficient_Y = zeros(1, n);  % 预定义系数数组
coefficient_X = zeros(1, n);  % 预定义系数数组

% 循环输入Y的系数
for i = 1:n
    coefficient_Y(i) = input('输入Y的系数：');
end

% 循环输入X的系数
for j = 1:n
    coefficient_X(j) = input('输入X的系数：');
end

E = TheCalledFunction(coefficient_Y);  % 调用函数，求出Y的多项式结果
F = TheCalledFunction(coefficient_X);  % 调用函数，求出X的多项式结果

disp('Y的多项式结果:');
disp(E);

disp('X的多项式结果:');
disp(F);

