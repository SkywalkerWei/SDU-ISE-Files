% TheCalledFunction.m
function cal = TheCalledFunction(xxi)
    N = length(xxi);  % 求多项式长度
    root = roots(xxi);  % 求根
    sort = cplxpair(root);  % 将求出的根按照复共轭对进行排序
    k = (N - 1) / 2;  % 计算级联个数

    % 下面的循环确定最终的多项式，poly 将一对根转化为对应的多项式
    for J = 1:k
        sortpro = [sort(2*J-1) sort(2*J)];  % 获取复共轭根对
        cal(J, :) = poly(sortpro);  % 生成对应的多项式
    end
end
