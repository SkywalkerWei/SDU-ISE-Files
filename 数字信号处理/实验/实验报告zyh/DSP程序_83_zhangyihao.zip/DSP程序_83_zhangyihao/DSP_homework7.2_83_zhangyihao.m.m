% 参数设置
wp = 0.7 * pi;    % 通带边界频率（弧度）
ws = 0.5 * pi;    % 阻带边界频率（弧度）
As = 55;          % 阻带衰减 (dB)
Fs = 2 * pi;      % 归一化采样频率

% 归一化频率
wp_norm = wp / Fs;  
ws_norm = ws / Fs;

% 估算滤波器阶数
delta_f = abs(wp_norm - ws_norm); % 过渡带宽
N = ceil((As - 7.95) / (2.285 * delta_f)); % 确定阶数
if mod(N, 2) == 1
    N = N + 1; % 确保阶数为偶数
end

% 滤波器设计：高通滤波器
f = [0 ws_norm wp_norm 1]; % 频率边界
m = [0 0 1 1];             % 幅度规格
h = firpm(N, f, m);        % 使用Parks-McClellan设计滤波器

% 画幅度响应（dB）
[H, w] = freqz(h, 1, 1024); % 计算频率响应
figure;
subplot(2, 1, 1);
plot(w / pi, 20 * log10(abs(H))); % 幅度响应（dB）
grid on;
xlabel('归一化频率 (\times\pi rad/sample)');
ylabel('幅度 (dB)');
title('幅度响应');

% 画相位响应
subplot(2, 1, 2);
plot(w / pi, angle(H)); % 相位响应
grid on;
xlabel('归一化频率 (\times\pi rad/sample)');
ylabel('相位 (rad)');
title('相位响应');

% 输出滤波器系数 h(n)
disp('滤波器系数 h(n):');
disp(h);
