% 定义分子和分母系数
x = [0.0528, 0.0797, 0.1295, 0.1295, 0.797, 0.0528];
y = [1, -1.8107, 2.4947, -1.8801, 0.9537, -0.2336];

% 获取零极点增益
[z, p, k] = tf2zp(x, y);

% 绘制零极点图
figure(1)
zplane(z, p);  % 注意这里改为传入 z 和 p

% 计算频率响应
[h, w] = freqz(x, y);
h_m = abs(h);

% 绘制频率幅度响应
figure(2)
plot(w, h_m);
title('频率幅度响应');
xlabel('w');
ylabel('|H(w)|');
grid on;

% 输出零、极点和增益
disp('z = ');
disp(z);
disp('p = ');
disp(p);
disp('k = ');
disp(k);
