% 给定的参数
wp = 0.2 * pi;  % 通带频率（角频率）
ws = 0.3 * pi;  % 阻带频率（角频率）
Rp = 1;         % 通带波动（dB）
Rs = 15;        % 阻带衰减（dB）

% 第一步：计算模拟 Butterworth 滤波器的阶数和截止频率
[N, wc] = buttord(wp/pi, ws/pi, Rp, Rs);  % 获取滤波器阶数 N 和归一化截止频率 wc

% 第二步：设计模拟 Butterworth 滤波器的系统函数
[b_s, a_s] = butter(N, wc, 's');  % 得到模拟滤波器的分子系数 b_s 和分母系数 a_s

% 第三步：使用双线性变换法将模拟滤波器转换为数字滤波器
Fs = 1;  % 采样频率，假设为 1 Hz
[b, a] = bilinear(b_s, a_s, Fs);  % 获取数字滤波器的分子系数 b 和分母系数 a

% 第四步：计算数字滤波器的频率响应
[H, w] = freqz(b, a, 512, 'whole');  % 计算频率响应

% 第五步：绘制幅度和相位响应
figure(1);
subplot(211);
mag = abs(H);  % 幅度响应
plot(w/pi, mag);  % 绘制幅度响应图
xlabel('归一化角频率 w/\pi');
ylabel('幅度');
title('数字低通滤波器的幅度响应');
grid on;

subplot(212);
phase = angle(H);  % 相位响应
plot(w/pi, phase);  % 绘制相位响应图
xlabel('归一化角频率 w/\pi');
ylabel('相位 (弧度)');
title('数字低通滤波器的相位响应');
grid on;

% 第六步：绘制增益（dB）响应
figure(2);
magdb = 20*log10(mag);  % 将幅度转换为dB
plot(w/pi, magdb);  % 绘制增益响应图
xlabel('归一化角频率 w/\pi');
ylabel('增益 (dB)');
title('数字低通滤波器的增益响应');
grid on;
